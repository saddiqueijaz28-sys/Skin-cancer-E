# Skin Cancer EDA + CNN — Streamlit Deployment

This package contains an updated Kaggle notebook and a Streamlit app.

## Files
- `app.py` — Streamlit interface for uploading an image and viewing the CNN's class scores.
- `Skin_Cancer_EDA_CNN.ipynb` — EDA and CNN training notebook for Kaggle.
- `requirements.txt` — Python dependencies for Streamlit Community Cloud.
- `class_names.json.example` — example format for class labels.

## Important: train the model first
The original ZIP did not contain a trained model, so the model binary is **not included**. The app will show setup instructions until the model files are added.

1. Upload `Skin_Cancer_EDA_CNN.ipynb` to Kaggle.
2. Add the `jaiahuja/skin-cancer-detection` dataset as notebook input.
3. Run all cells. The notebook saves `skin_cancer_cnn.keras`, `class_names.json`, and a CSV manifest.
4. Download `skin_cancer_cnn.keras` and `class_names.json` from the notebook output/files.
5. Add both files to the same GitHub repository as `app.py` (same directory).
6. On Streamlit Community Cloud, create a new app and select this repository, branch, and `app.py` as the main file.

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Medical limitation
This is an educational image-classification demonstration, not a medical device. It has not been clinically validated and must not be used to diagnose, rule out, or treat skin cancer. A model score is not a medical probability. Consult a qualified healthcare professional for medical concerns.
